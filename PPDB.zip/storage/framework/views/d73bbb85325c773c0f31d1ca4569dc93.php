

<?php $__env->startSection('content'); ?>
<div class="row">
    <div class="col-sm-6 col-xl-3">
        <div class="card">
            <div class="card-heading p-4">
                <div>
                    <input class="knob" data-width="80" data-height="80" data-linecap=round data-fgColor="#6cbafa" value="<?php echo e($total_pendaftar); ?>" data-skin="tron" data-angleOffset="180" data-readOnly=true data-thickness=".15" />
                    <div class="float-right">
                        <h2 class="text-primary mb-0"><?php echo e($total_pendaftar); ?></h2>
                        <p class="text-muted mb-0 mt-2">Total Pendaftar</p>
                    </div>                    
                </div>
            </div>
        </div>
    </div>

    <div class="col-sm-6 col-xl-3">
        <div class="card">
            <div class="card-heading p-4">
                <div>
                    <input class="knob" data-width="80" data-height="80" data-linecap=round data-fgColor="#61d7c7" value="<?php echo e($total_daftar_ulang); ?>" data-skin="tron" data-angleOffset="180" data-readOnly=true data-thickness=".15" />
                    <div class="float-right">
                        <h2 class="text-info mb-0"><?php echo e($total_daftar_ulang); ?></h2>
                        <p class="text-muted mb-0 mt-2">Total Siswa Daftar Ulang</p>
                    </div>                    
                </div>
            </div>
        </div>
    </div>

    <div class="col-sm-6 col-xl-3">
        <div class="card">
            <div class="card-heading p-4">
                <div>
                    <input class="knob" data-width="80" data-height="80" data-linecap=round data-fgColor="#6cbafa" value="<?php echo e($total_lulus); ?>" data-skin="tron" data-angleOffset="180" data-readOnly=true data-thickness=".15" />
                    <div class="float-right">
                        <h2 class="text-primary mb-0"><?php echo e($total_lulus); ?></h2>
                        <p class="text-muted mb-0 mt-2">Total Siswa Lulus</p>
                    </div>                    
                </div>
            </div>
        </div>
    </div>

    <div class="col-sm-6 col-xl-3">
        <div class="card">
            <div class="card-heading p-4">
                <div>
                    <input class="knob" data-width="80" data-height="80" data-linecap=round data-fgColor="#61d7c7" value="<?php echo e($total_siswa); ?>" data-skin="tron" data-angleOffset="180" data-readOnly=true data-thickness=".15" />
                    <div class="float-right">
                        <h2 class="text-info mb-0"><?php echo e($total_siswa); ?></h2>
                        <p class="text-muted mb-0 mt-2">Total Siswa</p>
                    </div>                    
                </div>
            </div>
        </div>
    </div>
</div>

<div class="col-lg-12 col-sm-12 col-12">
    <table id="datatable" class="table table-striped table-bordered dt-responsive nowrap" style="border-collapse: collapse; width: 100%;">
        <thead>
        <tr>
            <th>No</th>
            <th>Nama Lengkap</th>
            <th>Nisn</th>
            <th>Tempat Tanggal Lahir</th>
            <th>Alamat</th>
            <th>Jenis Kelamin</th>
            <th>Anak ke-</th>
            <th>Agama</th>
            <th>Asal Sekolah</th>
            <th>Negara</th>
            <th>No Regis</th>
            <th>Nama Orangtua</th>
            <th>No KK</th>
            <th>No Hp Orangtua</th>
            <th>Alamat Orangtua</th>
            
        </tr>
        </thead>


        <tbody>
            <?php $__currentLoopData = $berkas_siswa; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $b): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>                
            <tr>
                <td><?php echo e($loop->iteration); ?></td>
                <td><?php echo e($b->nama_lengkap); ?></td>
                <td><?php echo e($b->nisn); ?></td>
                <td><?php echo e($b->ttl); ?></td>
                <td><?php echo e($b->alamat); ?></td>
                <td><?php echo e($b->jenkel); ?></td>
                <td><?php echo e($b->anakke); ?></td>
                <td><?php echo e($b->agama); ?></td>
                <td><?php echo e($b->asal_sekolah); ?></td>
                <td><?php echo e($b->negara); ?></td>
                <td><?php echo e($b->no_reg); ?></td>
                <td><?php echo e($b->nama_ortu); ?></td>
                <td><?php echo e($b->no_kk); ?></td>
                <td><?php echo e($b->no_hp_ortu); ?></td>
                <td><?php echo e($b->alamat_ortu); ?></td>
            </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>        
        </tbody>
    </table>

</div>

<div class="row">

</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.template', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\ASUS\PPDB\resources\views/admin/laporan_ppdb.blade.php ENDPATH**/ ?>