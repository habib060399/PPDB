<?php $__env->startSection('content'); ?>

<div class="row">
    <div class="col-sm-12">
        <div class="card">
            <div class="card-body">
                <h1 class="m-t-0 m-b-30">SELAMAT DATANG DI WEBSITE PENERIMAAN PESERTA DIDIK BARU</h1>
                <a href="<?php echo e(route('pendaftaran')); ?>"><h5>Daftar</h5></a>
            </div> <!-- card-body -->
        </div> <!-- card -->
    </div> <!-- col -->
</div> <!-- End row -->
    
<?php $__env->stopSection(); ?>
<?php echo $__env->make('user.template', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\ASUS\PPDB\resources\views/user/index.blade.php ENDPATH**/ ?>