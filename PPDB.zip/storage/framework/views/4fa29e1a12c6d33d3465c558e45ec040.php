<!doctype html>
<html lang="en">


<head>
    <meta charset="utf-8" />
    <title>Hexzy - Responsive Admin Dashboard Template</title>
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
    <meta content="Admin Dashboard" name="description" />
    <meta content="ThemeDesign" name="author" />
    <meta http-equiv="X-UA-Compatible" content="IE=edge" />

    <link rel="shortcut icon" href="<?php echo e(url('assets/images/favicon.ico')); ?>">

    <!--Morris Chart CSS -->
    <link rel="stylesheet" href="<?php echo e(url('assets/plugins/morris/morris.css')); ?>">

    <link href="<?php echo e(url('assets/css/bootstrap.min.css')); ?>" rel="stylesheet" type="text/css">
    <link href="<?php echo e(url('assets/css/icons.css')); ?>" rel="stylesheet" type="text/css">
    <link href="<?php echo e(url('assets/css/style.css')); ?>" rel="stylesheet" type="text/css">

</head>

<body>

    <div class="header-bg">
        <!-- Navigation Bar-->
        <header id="topnav">
            <?php echo $__env->make('top_bar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
            <!-- end topbar-main -->

            <!-- MENU Start -->
            <div class="navbar-custom">
                <div class="container-fluid">

                    <div id="navigation">

                        <!-- Navigation Menu-->
                        <ul class="navigation-menu">

                            <li class="has-submenu">
                                <a href="<?php echo e(route('pendaftaran')); ?>"><i class="ti-home"></i> Pendaftaran</a>
                            </li>                            

                            <li class="has-submenu">
                                <a href="<?php echo e(route('pengumuman')); ?>"><i class="ti-files"></i> Pengumuman</a>                                
                            </li>

                        </ul>
                        <!-- End navigation menu -->
                    </div>
                    <!-- end #navigation -->
                </div>
                <!-- end container -->
            </div>
            <!-- end navbar-custom -->
        </header>
        <!-- End Navigation Bar-->

    </div>
    <!-- header-bg -->

    <div class="wrapper">
        <div class="container-fluid">           
            <?php echo $__env->yieldContent('content'); ?>
        </div>
        <!-- end wrapper -->

        <!-- Footer -->
        <footer class="footer">
            <div class="container-fluid">
                <div class="row">
                    <div class="col-12">
                        © 2019 - 2020 Hexzy <span class="d-none d-md-inline-block"> - Crafted with <i class="mdi mdi-heart text-danger"></i> by Themesdesign.</span>
                    </div>
                </div>
            </div>
        </footer>
        <!-- End Footer -->



        <!-- jQuery  -->
        <script src="<?php echo e(url('assets/js/jquery.min.js')); ?>"></script>
         <script src="<?php echo e(url('assets/js/bootstrap.bundle.min.js')); ?>"></script>
        <script src="<?php echo e(url('assets/js/modernizr.min.js')); ?>"></script>
        <script src="<?php echo e(url('assets/js/detect.js')); ?>"></script>
        <script src="<?php echo e(url('assets/js/fastclick.js')); ?>"></script>
        <script src="<?php echo e(url('assets/js/jquery.slimscroll.js')); ?>"></script>
        <script src="<?php echo e(url('assets/js/jquery.blockUI.js')); ?>"></script>
        <script src="<?php echo e(url('assets/js/waves.js')); ?>"></script>
        <script src="<?php echo e(url('assets/js/wow.min.js')); ?>"></script>
        <script src="<?php echo e(url('assets/js/jquery.nicescroll.js')); ?>"></script>
        <script src="<?php echo e(url('assets/js/jquery.scrollTo.min.js')); ?>"></script>

        <!--Morris Chart-->
        <script src="<?php echo e(url('assets/plugins/morris/morris.min.js')); ?>"></script>
        <script src="<?php echo e(url('assets/plugins/raphael/raphael.min.js')); ?>"></script>

        <!-- KNOB JS -->
        <script src="<?php echo e(url('assets/plugins/jquery-knob/excanvas.js')); ?>"></script>
        <script src="<?php echo e(url('assets/plugins/jquery-knob/jquery.knob.js')); ?>"></script>

        <script src="<?php echo e(url('assets/plugins/flot-chart/jquery.flot.min.js')); ?>"></script>
        <script src="<?php echo e(url('assets/plugins/flot-chart/jquery.flot.tooltip.min.js')); ?>"></script>
        <script src="<?php echo e(url('assets/plugins/flot-chart/jquery.flot.resize.js')); ?>"></script>
        <script src="<?php echo e(url('assets/plugins/flot-chart/jquery.flot.pie.js')); ?>"></script>
        <script src="<?php echo e(url('assets/plugins/flot-chart/jquery.flot.selection.js')); ?>"></script>
        <script src="<?php echo e(url('assets/plugins/flot-chart/jquery.flot.stack.js')); ?>"></script>
        <script src="<?php echo e(url('assets/plugins/flot-chart/jquery.flot.crosshair.js')); ?>"></script>

        <script src="<?php echo e(url('assets/pages/dashboard.js')); ?>"></script>

        <script src="<?php echo e(url('assets/js/app.js')); ?>"></script>

</body>

</html><?php /**PATH C:\Users\ASUS\PPDB\resources\views/user/template.blade.php ENDPATH**/ ?>